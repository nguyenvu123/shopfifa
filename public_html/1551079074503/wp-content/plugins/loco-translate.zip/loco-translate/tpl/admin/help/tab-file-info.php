<h2>
    File information
</h2>
<p>
    This screen shows technical information about the selected file.
    You may find it useful in debugging problems
</p>
<p>
    <a href="<?php echo esc_url(apply_filters('loco_external','https://localise.biz/wordpress/plugin/manual/filesystem'))?>" target="_blank">About filesystem access</a>
</p>